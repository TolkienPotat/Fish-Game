package dev.myFishGame;

public class Launcher {

	public static void main(String[] args) {

		Game game = new Game("FishGame", 960, 540);
		game.start();
		
	}

}
